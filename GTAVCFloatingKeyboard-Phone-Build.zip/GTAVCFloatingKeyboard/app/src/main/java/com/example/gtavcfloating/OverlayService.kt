package com.example.gtavcfloating

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.content.ClipboardManager
import android.content.ClipData
import android.widget.Toast

class OverlayService : Service() {
    companion object {
        const val ACTION_START = "com.example.gtavcfloating.START"
        const val ACTION_TOGGLE = "com.example.gtavcfloating.TOGGLE"
        private const val CHANNEL = "gta_vc_keyboard"
        private const val NOTIFICATION_ID = 73
    }

    private lateinit var wm: WindowManager
    private var panel: View? = null
    private var visible = false

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_TOGGLE -> if (visible) hidePanel() else showPanel()
            else -> showPanel()
        }
        return START_STICKY
    }

    private fun buildNotification(): Notification {
        val toggle = Intent(this, OverlayActionReceiver::class.java)
        val pending = PendingIntent.getBroadcast(
            this, 1, toggle,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val openApp = PendingIntent.getActivity(
            this, 2, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentTitle("GTA VC Floating Keyboard")
            .setContentText("Tap SHOW / HIDE to control the keyboard")
            .setContentIntent(openApp)
            .addAction(android.R.drawable.ic_menu_view, "SHOW / HIDE", pending)
            .setOngoing(true)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "Floating keyboard", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun showPanel() {
        if (visible) return
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(8, 8, 8, 8)
            background = rounded(0xEE191522.toInt(), 18)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "  GTA VC • QWERTY"
            textSize = 14f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        val hide = keyButton("×") { hidePanel() }
        header.addView(title, LinearLayout.LayoutParams(0, 42, 1f))
        header.addView(hide, LinearLayout.LayoutParams(48, 42))
        root.addView(header)

        val input = EditText(this).apply {
            hint = "Type cheat text here"
            textSize = 16f
            singleLine = true
            setTextColor(Color.WHITE)
            setHintTextColor(0xFFB9ADC9.toInt())
            setPadding(10, 4, 10, 4)
            background = rounded(0xFF30283D.toInt(), 8)
        }
        root.addView(input, LinearLayout.LayoutParams(-1, 46))

        val rows = listOf("QWERTYUIOP", "ASDFGHJKL", "ZXCVBNM")
        rows.forEach { row ->
            val line = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }
            row.forEach { ch ->
                line.addView(keyButton(ch.toString()) {
                    input.append(ch.toString().lowercase())
                }, LinearLayout.LayoutParams(0, 43, 1f).apply {
                    setMargins(2, 3, 2, 3)
                })
            }
            root.addView(line)
        }

        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        bottom.addView(keyButton("Shift") { /* visual modifier; GTA cheat codes are normally case-insensitive */ },
            LinearLayout.LayoutParams(0, 44, 1.2f).apply { setMargins(2, 2, 2, 2) })
        bottom.addView(keyButton("Space") { input.append(" ") },
            LinearLayout.LayoutParams(0, 44, 1.5f).apply { setMargins(2, 2, 2, 2) })
        bottom.addView(keyButton("⌫") {
            val s = input.text
            if (s.isNotEmpty()) s.delete(s.length - 1, s.length)
        }, LinearLayout.LayoutParams(0, 44, 1f).apply { setMargins(2, 2, 2, 2) })
        bottom.addView(keyButton("Clear") { input.setText("") },
            LinearLayout.LayoutParams(0, 44, 1f).apply { setMargins(2, 2, 2, 2) })
        root.addView(bottom)

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(keyButton("COPY") {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("GTA cheat", input.text.toString()))
            Toast.makeText(this@OverlayService, "Copied. Paste where the game accepts text.", Toast.LENGTH_SHORT).show()
        }, LinearLayout.LayoutParams(0, 42, 1f).apply { setMargins(2, 3, 2, 2) })
        actions.addView(keyButton("ENTER") {
            input.append("\n")
            Toast.makeText(this@OverlayService, "Enter added to the text. This overlay cannot inject keys into GTA.", Toast.LENGTH_LONG).show()
        }, LinearLayout.LayoutParams(0, 42, 1f).apply { setMargins(2, 3, 2, 2) })
        root.addView(actions)

        // Drag the panel by holding its title area.
        var startX = 0; var startY = 0; var touchX = 0f; var touchY = 0f
        title.setOnTouchListener { _, event ->
            val lp = panel?.layoutParams as? WindowManager.LayoutParams
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp?.x ?: 0; startY = lp?.y ?: 0
                    touchX = event.rawX; touchY = event.rawY; true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (lp != null) {
                        lp.x = startX + (event.rawX - touchX).toInt()
                        lp.y = startY + (event.rawY - touchY).toInt()
                        wm.updateViewLayout(panel, lp)
                    }
                    true
                }
                else -> true
            }
        }

        val type = if (Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = 160
        }
        panel = root
        wm.addView(root, params)
        visible = true
    }

    private fun hidePanel() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
        visible = false
    }

    private fun keyButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            textSize = 11f
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = rounded(0xFF49365F.toInt(), 8)
            setOnClickListener { action() }
        }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
    }

    override fun onDestroy() {
        hidePanel()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
