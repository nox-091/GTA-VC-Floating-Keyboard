package com.example.gtavcfloating

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class OverlayActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val serviceIntent = Intent(context, OverlayService::class.java).setAction(OverlayService.ACTION_TOGGLE)
        if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(serviceIntent)
        else context.startService(serviceIntent)
    }
}
