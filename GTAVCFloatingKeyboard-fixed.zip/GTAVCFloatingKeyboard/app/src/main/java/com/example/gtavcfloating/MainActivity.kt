package com.example.gtavcfloating

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 28)
            setBackgroundColor(0xFF17131F.toInt())
        }
        val title = TextView(this).apply {
            text = "GTA VC Floating Keyboard"
            textSize = 23f
            setTextColor(0xFFFFFFFF.toInt())
        }
        val info = TextView(this).apply {
            text = "Enable overlay permission, then start the keyboard. Use the notification to show or hide it while playing."
            textSize = 15f
            setTextColor(0xFFD8D0E5.toInt())
            setPadding(0, 18, 0, 22)
        }
        val permission = Button(this).apply {
            text = "1. Allow display over other apps"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else Toast.makeText(this@MainActivity, "Overlay permission already allowed", Toast.LENGTH_SHORT).show()
            }
        }
        val start = Button(this).apply {
            text = "2. Start floating keyboard"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(this@MainActivity, "Allow overlay permission first", Toast.LENGTH_LONG).show()
                } else {
                    val intent = Intent(this@MainActivity, OverlayService::class.java)
                        .setAction(OverlayService.ACTION_START)
                    if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
                    Toast.makeText(this@MainActivity, "Keyboard service started", Toast.LENGTH_SHORT).show()
                }
            }
        }
        val stop = Button(this).apply {
            text = "Stop floating keyboard"
            setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) }
        }
        root.addView(title); root.addView(info); root.addView(permission)
        root.addView(start); root.addView(stop)
        setContentView(root)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 40)
        }
    }
}
