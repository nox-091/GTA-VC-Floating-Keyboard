# GTA VC Floating Keyboard (Android starter project)

This is an Android Studio Kotlin project for a movable floating QWERTY text panel and a persistent notification with a SHOW / HIDE action.

## Build
1. Install Android Studio (current stable) and Android SDK 35.
2. Open this folder in Android Studio.
3. Let Gradle sync.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Install the APK on your Android phone.

## First launch
1. Open the app.
2. Tap **Allow display over other apps** and enable the permission.
3. Return to the app and tap **Start floating keyboard**.
4. Start GTA Vice City. Use the notification's **SHOW / HIDE** action to show or hide the panel.

## Important limitation
Android does not let an ordinary overlay app inject arbitrary keyboard events into another app/game. This starter provides a floating QWERTY text pad and clipboard copy, but it cannot directly type cheat codes into GTA Vice City. Clipboard paste also only works if the game exposes a text-entry field that accepts paste. Direct game input would require a supported input method or game-side/OS-level input support; this app does not bypass Android's security model.

The notification permission prompt is requested on Android 13+. Android may also impose foreground-service restrictions depending on OS version and device manufacturer.
