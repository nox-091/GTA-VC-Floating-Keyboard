# Build the APK using only your Android phone

1. In Chrome, sign in to GitHub and create a **public or private repository** named `GTA-VC-Floating-Keyboard`.
2. Upload the contents of this project ZIP to the repository's `main` branch. Make sure the `.github/workflows/android-apk.yml` file is included. If GitHub's mobile upload screen hides dot-folders, create `.github/workflows/android-apk.yml` using GitHub's web editor.
3. Open the repository's **Actions** tab.
4. Select **Build GTA VC Floating Keyboard APK** and tap **Run workflow** (or push/upload a commit to `main`, which also triggers a build).
5. Wait for the workflow to finish successfully.
6. Open the completed workflow run, scroll to **Artifacts**, and download `GTA-VC-Floating-Keyboard-debug`.
7. Extract the downloaded artifact ZIP and install `app-debug.apk` on your Android phone. You may need to allow Chrome or your file manager to install unknown apps.

Notes:
- This workflow builds a debug APK; it is suitable for personal testing, not Play Store publishing.
- The app requires Android's "Display over other apps" permission.
- The overlay can display a floating QWERTY panel and copy text. It cannot directly inject keyboard events into GTA Vice City; the game must accept compatible text/keyboard input for cheats to work.
